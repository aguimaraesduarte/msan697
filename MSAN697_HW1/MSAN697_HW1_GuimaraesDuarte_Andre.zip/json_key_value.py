import json

def count_data(data, key):
    return len(data[key])

def get_data_value(data, key):
    return data[key]

