dbname = "ecommerce"
usr_name = "andre"
input_file_name = "walmart_search_san_francisco.json"
