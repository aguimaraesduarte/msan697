dbname = "ecommerce"
collection_name = "items"
input_file_name = "walmart_search_san_francisco.json"
